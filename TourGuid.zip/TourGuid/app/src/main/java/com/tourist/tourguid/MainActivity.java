///////////////////////////////////////////////////////////////////////////////////////
//
//  Category.java
//  TourGuide For Navigation Drawer
//
//  class for category show and select
//
//  Created by Xiaoming Yu  on 01/28/2018.
//
///////////////////////////////////////////////////////////////////////////////////////

// package class name
package com.tourist.tourguid;

// import class name
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListAdapter;
import com.tourist.tourguid.Category;
import com.tourist.tourguid.R;
import com.tourist.tourguid.Subcategory;
import java.util.ArrayList;

// MainActivity class
public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener,
        Category.OnFragmentInteractionListener,
        Subcategory.OnFragmentInteractionListener,
        Detail.OnFragmentInteractionListener{

    // member variable
    // category detail data
    public DataManager m_dataManager;
    // selected category index
    public   int m_selectedCategoryIndex = 0;
    // selected sub category index
    public   int m_selectedSubCategoryIndex = 0;
    // sub category name array
    ArrayList<String> m_subCategoryNameArray;
    // sub category photo array
    ArrayList<Integer> m_subCategoryPhotoArray;

    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    // CategoryActivity create
    //
    // inp: savedInstanceState - bundle
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        // category detail data init
        m_dataManager = new DataManager();
        // category array set
        onSetCategory();
        // all detail data set
        onSetDetailData();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if (savedInstanceState == null) {
            Fragment fragment = null;
            Class fragmentClass = null;
            fragmentClass = Category.class;
            try {
                fragment = (Fragment) fragmentClass.newInstance();
            } catch (Exception e) {
                e.printStackTrace();
            }

            FragmentManager fragmentManager = getSupportFragmentManager();
            fragmentManager.beginTransaction().replace(R.id.flContent, fragment).commit();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    // navigation item select process
    //
    // inp: item - menu item
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        Fragment fragment = null;
        Class fragmentClass = null;
        // category item ?
        if (id == R.id.nav_category) {
            fragmentClass = Category.class;
        }
        // sub category item ?
        else if (id == R.id.nav_subcategory) {
            fragmentClass = Subcategory.class;
        }
        // detail ?
        else{
            fragmentClass = Detail.class;
        }
        try {
            fragment = (Fragment) fragmentClass.newInstance();
        } catch (Exception e) {
            e.printStackTrace();
        }
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.flContent, fragment).commit();

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    // fragment interaction
    //
    // inp: uri - uri
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public void onFragmentInteraction(Uri uri) {

    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    // Set the category name
    //
    //  set the 4 category
    //
    // inp: none
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    public void onSetCategory() {
        int categoryCount = 4;
        m_dataManager.m_categoryArray = new String[categoryCount];
        m_dataManager.m_categoryArray[0] = this.getResources().getString( R.string.category1 );
        m_dataManager.m_categoryArray[1] = this.getResources().getString( R.string.category2 );
        m_dataManager.m_categoryArray[2] = this.getResources().getString( R.string.category3 );
        m_dataManager.m_categoryArray[3] = this.getResources().getString( R.string.category4 );
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    // Set the title for category
    //
    //  Show the categoty name by selected category
    //
    // inp: none
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    public void onSetTitleForCategory() {
        int titleId;
        switch( m_selectedCategoryIndex )
        {
            case 0:
                titleId = R.string.category1;
                break;
            case 1:
                titleId = R.string.category2;
                break;
            case 2:
                titleId = R.string.category3;
                break;
            default:
                titleId = R.string.category4;
                break;
        }
        getSupportActionBar().setTitle( getResources().getString( titleId ) );
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    // Set the title for sub category
    //
    //  Show the sub categoty name by selected sub category
    //
    // inp: none
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    public void onSetTitleForSubcategory() {
        getSupportActionBar().setTitle( m_subCategoryNameArray.get(m_selectedSubCategoryIndex) );
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    // Set the title for sub category content( name & photo )
    //
    //  Show the sub categoty content by selected category
    //
    // inp: none
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    public void onSetSubcategoryContent()
    {
        // all data init
        m_subCategoryNameArray = new ArrayList<>();
        m_subCategoryPhotoArray = new ArrayList<>();

        ArrayList<ItemData> arrayList;
        // If selected the hotel, get the hotel data
        if ( m_selectedCategoryIndex == 0 ) {
            arrayList = m_dataManager.getHotelArray();
        }
        // If selected the restaurant, get the restaurant data
        else if (m_selectedCategoryIndex == 1) {
            arrayList = m_dataManager.getReataurantArray();
        }
        // If selected the beautiful place, get the beautiful place ata
        else if (m_selectedCategoryIndex == 2) {
            arrayList = m_dataManager.getBeautifulPlaceArray();
        }
        // If selected the ruins, get the ruins ata
        else  {
            arrayList = m_dataManager.getRuinsArray();
        }

        for (int i = 0; i < arrayList.size(); i ++) {
            m_subCategoryNameArray.add(arrayList.get(i).getName());
            m_subCategoryPhotoArray.add(arrayList.get(i).getImageThumb());
        }
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //  Set all detail data
    //
    // inp: none
    // out: none
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    private void onSetDetailData() {
        String nameStr;
        String detailStr;
        ItemData detailAllData;

        // detil for Hotel
        // french hotel
        nameStr = this.getResources().getString( R.string.french_title );
        detailStr = this.getResources().getString( R.string.french_detail1 ) +
                this.getResources().getString( R.string.french_detail2 ) +
                this.getResources().getString( R.string.french_detail3 );
        detailAllData = new ItemData(nameStr, R.drawable.french_thumb, R.drawable.french_front, detailStr, R.drawable.french_loc);
        m_dataManager.m_itemArray.add(detailAllData);

        // west hotel
        nameStr = this.getResources().getString( R.string.west_title );
        detailStr = this.getResources().getString( R.string.west_detail1 ) +
                this.getResources().getString( R.string.west_detail2 ) +
                this.getResources().getString( R.string.west_detail3 );
        detailAllData = new ItemData(nameStr, R.drawable.west_thumb, R.drawable.west_front, detailStr, R.drawable.west_loc);
        m_dataManager.m_itemArray.add(detailAllData);

        // detil for restaurant
        // royal restaurant
        nameStr = this.getResources().getString( R.string.royal_title );
        detailStr = this.getResources().getString( R.string.royal_detail1) +
                this.getResources().getString( R.string.royal_detail2 ) +
                this.getResources().getString( R.string.royal_detail3 ) +
                this.getResources().getString( R.string.royal_detail4 ) +
                this.getResources().getString( R.string.royal_detail5 );
        detailAllData = new ItemData(nameStr, R.drawable.royal_thumb, R.drawable.royal_front, detailStr, R.drawable.royal_loc);
        m_dataManager.m_itemArray.add(detailAllData);

        // yaoman restaurant
        nameStr = this.getResources().getString( R.string.yaoman_title );
        detailStr = this.getResources().getString( R.string.yaoman_detail1) +
                this.getResources().getString( R.string.yaoman_detail2 ) +
                this.getResources().getString( R.string.yaoman_detail3 ) +
                this.getResources().getString( R.string.yaoman_detail4 ) +
                this.getResources().getString( R.string.yaoman_detail5 );
        detailAllData = new ItemData(nameStr, R.drawable.yaoman_thumb, R.drawable.yaoman_front, detailStr, R.drawable.yaomen_loc);
        m_dataManager.m_itemArray.add(detailAllData);

        // detil for Beautiful Place
        // Minnesota's ice Castles
        nameStr = this.getResources().getString( R.string.minnesota_title );
        detailStr = this.getResources().getString( R.string.minnesota_detail1) +
                this.getResources().getString( R.string.minnesota_detail2 ) +
                this.getResources().getString( R.string.minnesota_detail3 ) +
                this.getResources().getString( R.string.minnesota_detail4 );
        detailAllData = new ItemData(nameStr, R.drawable.minnesota_thumb, R.drawable.minnesota_front, detailStr, R.drawable.minnesota_loc);
        m_dataManager.m_itemArray.add(detailAllData);

        // National park
        nameStr = this.getResources().getString( R.string.park_title );
        detailStr = this.getResources().getString( R.string.park_detail1) +
                this.getResources().getString( R.string.park_detail2 ) +
                this.getResources().getString( R.string.park_detail3 ) +
                this.getResources().getString( R.string.park_detail4 );
        detailAllData = new ItemData(nameStr, R.drawable.parks_thumb, R.drawable.parks_front, detailStr, R.drawable.parks_loc);
        m_dataManager.m_itemArray.add(detailAllData);

        // detil for Ruins
        // Roman Bath
        nameStr = this.getResources().getString( R.string.bath_title );
        detailStr = this.getResources().getString( R.string.bath_detail1) +
                this.getResources().getString( R.string.bath_detail2 ) +
                this.getResources().getString( R.string.bath_detail3 );
        detailAllData = new ItemData(nameStr, R.drawable.bath_thumb, R.drawable.bath_front, detailStr, R.drawable.bath_loc);
        m_dataManager.m_itemArray.add(detailAllData);

        // Petra
        nameStr = this.getResources().getString( R.string.petra_title );
        detailStr = this.getResources().getString( R.string.petra_detail1) +
                this.getResources().getString( R.string.petra_detail2 ) +
                this.getResources().getString( R.string.petra_detail3 );
        detailAllData = new ItemData(nameStr, R.drawable.petra_thumb, R.drawable.petra_front, detailStr, R.drawable.petra_loc);
        m_dataManager.m_itemArray.add(detailAllData);

    }

}
