///////////////////////////////////////////////////////////////////////////////////////
//
//  Subcategory.java
//  TourGuide For Navigation Drawer
//
//  Show the sub category data
//
//  Created by Xiaoming Yu  on 01/28/2018.
//
///////////////////////////////////////////////////////////////////////////////////////

// package class name
package com.tourist.tourguid;

// import class name
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;

//  Subcategory class
public class Subcategory extends Fragment {
    // member variable
    // main activity object
    private MainActivity m_objMainActivity;
    // Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String m_argParam1Str = "param1";
    private static final String m_argParam2Str = "param2";
    private String m_param1Str;
    private String m_param2Str;
    private OnFragmentInteractionListener m_listener;

    ///////////////////////////////////////////////////////////////////////////
    // class constructor
    //
    ///////////////////////////////////////////////////////////////////////////
    public Subcategory() {
        // Required empty public constructor
    }

    ///////////////////////////////////////////////////////////////////////////
    // class new instance constructor
    //
    // Use this factory method to create a new instance of
    // this fragment using the provided parameters.
    //
    // inp: param1 - Parameter 1
    //      param2 - Parameter 2
    // out: A new instance of fragment Category
    ///////////////////////////////////////////////////////////////////////////
    public static Subcategory newInstance(String param1, String param2) {
        Subcategory fragment = new Subcategory();
        Bundle args = new Bundle();
        args.putString(m_argParam1Str, param1);
        args.putString(m_argParam2Str, param2);
        fragment.setArguments(args);
        return fragment;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    // Categor create
    //
    // inp: savedInstanceState - bundle
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            m_param1Str = getArguments().getString(m_argParam1Str);
            m_param2Str = getArguments().getString(m_argParam2Str);
        }
        // Get the main activity object
        m_objMainActivity = (MainActivity)getActivity();
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    // view create
    //
    // inp: inflater - layout inflater
    //      container - view group
    //      savedInstanceState - bundle
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_subcategory, container, false);
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    // Resume
    //
    // show the category and set the title
    //
    // inp: none
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public void onResume() {
        super.onResume();

        m_objMainActivity.onSetSubcategoryContent();
        // list adapter
        ListAdapter m_listAdapter;
        // set adapter for sub category's name & photo
        m_listAdapter = new CustomListAdapter(getActivity(), m_objMainActivity.m_subCategoryNameArray,
                m_objMainActivity.m_subCategoryPhotoArray);


        // make of list view for sub category's name & photo
        ListView listSubCategory = getView().findViewById(R.id.list_subCategory);
        listSubCategory.setAdapter(m_listAdapter);

        // when sub category selected, go to detail
        listSubCategory.setOnItemClickListener(new ListView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                m_objMainActivity.m_selectedSubCategoryIndex = position;
                m_objMainActivity.onSetTitleForSubcategory();

            }
        });

        // title set
        m_objMainActivity.onSetTitleForSubcategory();
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    // button pressed
    //
    // Rename method, update argument and hook method into UI event
    //
    // inp: uri - uri
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    public void onButtonPressed(Uri uri) {
        if (m_listener != null) {
            m_listener.onFragmentInteraction(uri);
        }
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    // Attach method
    //
    // inp: context - context
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        String attachStr = getResources().getString( R.string.attach_string );
        if (context instanceof OnFragmentInteractionListener) {
            m_listener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString() + attachStr);
        }
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    // Detach method
    //
    // inp: context - context
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public void onDetach() {
        super.onDetach();
        m_listener = null;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    // Fragment interaction listener
    //
    // inp: none
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    public interface OnFragmentInteractionListener {
        void onFragmentInteraction(Uri uri);
    }
}
