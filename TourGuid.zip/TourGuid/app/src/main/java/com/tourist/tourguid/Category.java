///////////////////////////////////////////////////////////////////////////////////////
//
//  Category.java
//  TourGuide For Navigation Drawer
//
//  class for category show and select
//
//  Created by Xiaoming Yu  on 01/28/2018.
//
///////////////////////////////////////////////////////////////////////////////////////

// package class name
package com.tourist.tourguid;

// import class name
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

//  Category class
public class Category extends Fragment {
    // member variable

    // main activity object
    private MainActivity m_objMainActivity;
    // Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static String m_argParam1 = "param1";
    private static String m_argParam2 = "param2";
    private String m_param1Str;
    private String m_param2Str;

    // Fragment Interaction Listener
    private OnFragmentInteractionListener m_listener;

    ///////////////////////////////////////////////////////////////////////////
    // class constructor
    //
    ///////////////////////////////////////////////////////////////////////////
    public Category() {
    }

    ///////////////////////////////////////////////////////////////////////////
    // class new instance constructor
    //
    // Use this factory method to create a new instance of
    // this fragment using the provided parameters.
    //
    // inp: param1 - Parameter 1
    //      param2 - Parameter 2
    // out: A new instance of fragment Category
    ///////////////////////////////////////////////////////////////////////////
    public static Category newInstance(String param1, String param2) {
        Category fragment = new Category();
        Bundle args = new Bundle();
        args.putString(m_argParam1, param1);
        args.putString(m_argParam2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    // Categor create
    //
    // inp: savedInstanceState - bundle
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            m_param1Str = getArguments().getString(m_argParam1);
            m_param2Str = getArguments().getString(m_argParam2);
        }
        // set the main activity object
        m_objMainActivity = (MainActivity)getActivity();
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    // view create
    //
    // inp: inflater - layout inflater
    //      container - view group
    //      savedInstanceState - bundle
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_category, container, false);
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    // Resume
    //
    // show the category and set the title
    //
    // inp: none
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public void onResume() {
        super.onResume();

        // category list set
        // set the cell style & data
        ArrayAdapter adapter = new ArrayAdapter<>(getActivity(), R.layout.list_category_style, m_objMainActivity.m_dataManager.m_categoryArray);
        ListView listView = getView().findViewById( R.id.list_category );
        listView.setAdapter(adapter);

        // when category selected, go to sub category
        listView.setOnItemClickListener(new ListView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                m_objMainActivity.m_selectedCategoryIndex = position;
                // When chenged category, Set sub category index = 0
                m_objMainActivity.m_selectedSubCategoryIndex = 0;
                m_objMainActivity.onSetTitleForCategory();

            }
        });
        // title set
        m_objMainActivity.onSetTitleForCategory();
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    // button pressed
    //
    // Rename method, update argument and hook method into UI event
    //
    // inp: uri - uri
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    public void onButtonPressed(Uri uri) {
        if (m_listener != null) {
            m_listener.onFragmentInteraction(uri);
        }
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    // Attach method
    //
    // inp: context - context
    // out: none
    ///////////////////////////////////////
    ////////////////////////////////////////////////////////////////////
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        String attachStr = getResources().getString( R.string.attach_string );
        if (context instanceof OnFragmentInteractionListener) {
            m_listener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString() + attachStr);
        }
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    // Detach method
    //
    // inp: context - context
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public void onDetach() {
        super.onDetach();
        m_listener = null;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    // Fragment interaction listener
    //
    // inp: none
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    public interface OnFragmentInteractionListener {
        void onFragmentInteraction(Uri uri);
    }
}
