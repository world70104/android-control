/////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  CustomListAdapter.java
//  TourGuide For Navigation Drawer
//
//  Adapter for custom list view
//
//  Created by Xiaoming Yu  on 01/24/2018.
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////

// package name
package com.tourist.tourguid;

// import name
import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

// CustomListAdapter
public class CustomListAdapter extends BaseAdapter {
    // member variable
    // name item arrray
    private ArrayList<String> m_nameItemArray;
    // photo item arrray
    private ArrayList<Integer> m_photoItemArray;
    // layout inflater
    private static LayoutInflater inflater = null;

    ///////////////////////////////////////////////////////////////////////////
    // init CustomListAdapter ( class constructor )
    //
    // inp: nameItemArray - name item array for setting
    //      photoItemArray - photo item array
    // out: none
    ///////////////////////////////////////////////////////////////////////////
    CustomListAdapter(Context context, ArrayList<String> nameItemArray,
                      ArrayList<Integer> photoItemArray) {
        // load the item array for name and photo
        this.m_nameItemArray = nameItemArray;
        this.m_photoItemArray = photoItemArray;

        // get the layout inflater
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    ////////////////////////////////////////////////////////////////////////////////////////
    // get the name item array count
    //
    // inp: none
    // out: count
    ////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public int getCount() {
        return m_nameItemArray.size();
    }

    ////////////////////////////////////////////////////////////////////////////////////////
    // get the seleted name
    //
    // inp: index - selected position
    // out: seleted name
    ////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public Object getItem(int position) {
        return m_nameItemArray.get(position);
    }

    ////////////////////////////////////////////////////////////////////////////////////////
    // get the item ID
    //
    // inp: position
    // out: position
    ////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public long getItemId(int position) {
        return position;
    }

    ////////////////////////////////////////////////////////////////////////////////////////
    // get the custom list view
    //
    // inp: position -  position
    //      convertView - convert view
    //      parent - parent
    // out: view
    ////////////////////////////////////////////////////////////////////////////////////////
    @SuppressLint("InflateParams")
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (view == null)
            view = inflater.inflate(R.layout.custom_listitem, null);

        // set image thumb item
        ImageView imageView = view.findViewById(R.id.listitem_thumb);
        imageView.setImageResource(m_photoItemArray.get(position));

        // set text(title) item
        TextView text = view.findViewById(R.id.listitem_title);
        text.setText(m_nameItemArray.get(position));

        return view;
    }
}
