///////////////////////////////////////////////////////////////////////////////////////
//
//  ItemData.java
//  TourGuide For Navigation Drawer
//
//  data class for sub category detail
//
//  Created by Xiaoming Yu  on 01/24/2018.
//
///////////////////////////////////////////////////////////////////////////////////////

// package name
package com.tourist.tourguid;

//  data class for sub category detail
class ItemData {

    //  Name
    private String m_name;
    //  thumb image
    private int m_imageThumb;
    //  image path
    private int m_imagePath;
    //  detail
    private String m_detail;
    //  location image
    private int m_imageLocation;

    ///////////////////////////////////////////////////////////////////////////
    // load the init data ( class constructor )
    //
    // inp: name - name
    //      thumb - thumb
    //      image - image
    //      detail - detail
    //      location - location
    // out: image thumb
    ///////////////////////////////////////////////////////////////////////////
    ItemData(String name, int thumb, int image, String detail, int location) {
        this.m_name = name;
        this.m_imageThumb = thumb;
        this.m_imagePath = image;
        this.m_detail = detail;
        this.m_imageLocation = location;
    }

    //////////////////////////////////////////////
    // Get the name
    //
    // inp: none
    // out: name
    //////////////////////////////////////////////
    String getName() {
        return this.m_name;
    }

    //////////////////////////////////////////////
    // Get the image thumb
    //
    // inp: none
    // out: image thumb
    //////////////////////////////////////////////
    int getImageThumb() {
        return m_imageThumb;
    }

    //////////////////////////////////////////////
    // Get the image path
    //
    // inp: none
    // out: image path
    //////////////////////////////////////////////
    int getImagePath() {
        return m_imagePath;
    }

    //////////////////////////////////////////////
    // Get the detail
    //
    // inp: none
    // out: detail
    //////////////////////////////////////////////
    String getDetail() {
        return m_detail;
    }

    //////////////////////////////////////////////
    // Get the image location
    //
    // inp: none
    // out: image location
    //////////////////////////////////////////////
    int getImageLocation() {
        return m_imageLocation;
    }
}