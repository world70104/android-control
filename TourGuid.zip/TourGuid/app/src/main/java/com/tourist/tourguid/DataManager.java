////////////////////////////////////////////////////////////////////////////////////////////////
//
//  DataManager.java
//  TourGuide For Navigation Drawer
//
//  data manager class for sub category detail
//
//  Created by Xiaoming Yu  on 01/24/2018.
//
////////////////////////////////////////////////////////////////////////////////////////////////

// package name
package com.tourist.tourguid;

// import name
import java.util.ArrayList;

//  data manager class for sub category detail
class DataManager {
    // member variable
    // category array
    public String[] m_categoryArray;
    // data list array
    public ArrayList<ItemData> m_itemArray;
    // selected category string
    private static String m_selectedCategoryStr;
    // selected sub category string
    private static String m_selectedSubCategoryStr;

    ////////////////////////////////////////////////////////////////////////////////////////////
    // init
    //
    // initialoze the all data
    // inp: none
    // out: none
    /////////////////////////////////////////////////////////////////////////////////////////////
    DataManager() {
        if (m_itemArray == null) {
            m_itemArray = new ArrayList<>();
            m_selectedCategoryStr = "";
            m_selectedSubCategoryStr = "";
        }
    }

    /////////////////////////////////////////////////////////
    //  Set the selected category name
    //
    // inp: categoryStr - category string for setting
    // out: none
    /////////////////////////////////////////////////////////
    void setCategoryName(String categoryStr) {
        m_selectedCategoryStr = categoryStr;
    }

    /////////////////////////////////////////////////////////
    //  Get the selected category name
    //
    // inp: none
    // out: category string
    /////////////////////////////////////////////////////////
    String getCategoryName() {
        return m_selectedCategoryStr;
    }

    void setSubCategoryName(String strSubCategory) {
        m_selectedSubCategoryStr = strSubCategory;
    }

    /////////////////////////////////////////////////////////
    //  Get the selected sub category name
    //
    // inp: none
    // out: sub category string
    /////////////////////////////////////////////////////////
    String getSubCategoryName() {
        return m_selectedSubCategoryStr;
    }

    /////////////////////////////////////////////////////////
    //  Get the hotel name array
    //
    // inp: none
    // out: hotel name array
    /////////////////////////////////////////////////////////
    ArrayList<ItemData> getHotelArray() {

        ArrayList<ItemData> retArray = new ArrayList<>();
        // hotel name array indexs: 0 ~ 1
        retArray.add(m_itemArray.get(0));
        retArray.add(m_itemArray.get(1));

        return retArray;
    }

    /////////////////////////////////////////////////////////
    //  Get the Reataurant name array
    //
    // inp: none
    // out: Reataurant name array
    /////////////////////////////////////////////////////////
    ArrayList<ItemData> getReataurantArray() {

        ArrayList<ItemData> retArray = new ArrayList<>();
        // Reataurant name array indexs: 2 ~ 3
        retArray.add(m_itemArray.get(2));
        retArray.add(m_itemArray.get(3));

        return retArray;
    }

    /////////////////////////////////////////////////////////
    //  Get the beautiful place's name array
    //
    // inp: none
    // out:  beautiful place name array
    /////////////////////////////////////////////////////////
    ArrayList<ItemData> getBeautifulPlaceArray() {

        ArrayList<ItemData> retArray = new ArrayList<>();
        // beautiful place array indexs: 4 ~ 5
        retArray.add(m_itemArray.get(4));
        retArray.add(m_itemArray.get(5));

        return retArray;
    }

    /////////////////////////////////////////////////////////
    //  Get the Ruins name array
    //
    // inp: none
    // out:  Ruins array
    /////////////////////////////////////////////////////////
    ArrayList<ItemData> getRuinsArray() {

        ArrayList<ItemData> retArray = new ArrayList<>();
        // Ruins array indexs: 6 ~ 7
        retArray.add(m_itemArray.get(6));
        retArray.add(m_itemArray.get(7));

        return retArray;
    }

    ///////////////////////////////////////////////////////////////////////
    //  Get the detail for seletec sub category name
    //
    // inp: strSelectedSubCategory - seletec sub category name
    // out: null - check fail
    //      no null - detail of seleleted sub category name
    ////////////////////////////////////////////////////////////////////////
    ItemData getSelectedData( String strSelectedSubCategory ) {
        // check of sub category name
        for (int idx = 0; idx < m_itemArray.size(); idx ++) {
            if (strSelectedSubCategory.equals(m_itemArray.get(idx).getName()))
                return m_itemArray.get(idx);
        }

        return null;
    }
}
