////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  ValidateCheck.java
//  Inventory App For SQlite, Content Provider, Loader,  CursorAdapter
//
//  Created by Xiaoming Yu  on 02/02/2018.
//
////////////////////////////////////////////////////////////////////////////////////////////////////

// package class name
package com.inventory.inventory;
// import class name
import android.provider.BaseColumns;
// SeeActivity class
public class ValidateCheck {
    // variable
    private  final int mMiniCharacterCount = 2; // no space
    private  final int mMiniPhoneNumberCount = 8; // no space
    private  final int mMiniEmailCount = 5; // no space
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // constructor
    //
    // inp: none
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    public ValidateCheck()
    {

    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // phone number check
    //
    // inp: strPhoneNumber - phone number for check
    // out: -1 : invalid
    //      other : valid phone number
    ////////////////////////////////////////////////////////////////////////////////////////////////
    public String PhoneNumberValidateCheck( String strPhoneNumber )
    {
        String retStr;
        retStr = strPhoneNumber.trim();
        // length == 0 ?
        if( retStr.isEmpty() )
            retStr = "";
        // length < mPhoneNumberCount ?
        else if( retStr.length() < mMiniPhoneNumberCount )
            retStr = "";
        else
        {
            // country code == 00 ?
            if( !(( retStr.charAt(0) == '0' ) &&
                    ( retStr.charAt(1) == '0' )))
                retStr = "";
            else
            {
                // check number array?
                int idx;
                for( idx = 0; idx < retStr.length(); idx++ ) {
                    if (!(retStr.charAt(idx) >= '0' &&
                            retStr.charAt(idx) <= '9')) {
                        break;
                    }
                }
                if( idx < retStr.length() )
                    retStr = "";
            }
        }
        return retStr;
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // price and quantity check
    //
    // inp: strValue - value for check
    // out: -1 : invalid
    //      other : valid value
    ////////////////////////////////////////////////////////////////////////////////////////////////
    public int PriceQuantityValidateCheck( String strValue )
    {
        int retInt;
        retInt = -1;
        strValue = strValue.trim();
        try{
            retInt = Integer.parseInt(strValue);
            return retInt;
        }
        catch (NumberFormatException e) {
            return retInt; // consume.
        }
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // email check
    //
    // inp: strEmail - email for check
    // out: -1 : invalid
    //      other : valid email
    ////////////////////////////////////////////////////////////////////////////////////////////////
    public String EmailValidateCheck( String strEmail )
    {
        String retStr;
        retStr = strEmail.trim();
        // length == 0 ?
        if( retStr.isEmpty() )
            retStr = "";
            // length < mPhoneNumberCount ?
        else if( retStr.length() < mMiniEmailCount )
            retStr = "";
        else if(!(retStr.contains("@") && retStr.contains("."))) {
            retStr = "";
        }

        return retStr;
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // characters check
    //
    // inp: strCharacters - valus for check
    // out: -1 : invalid
    //      other : valid valus
    ////////////////////////////////////////////////////////////////////////////////////////////////
    public String CharacterValidateCheck( String strCharacters )
    {
        String retStr;
        retStr = strCharacters.trim();
        // length == 0 ?
        if( retStr.isEmpty() )
            retStr = "";
            // length < mPhoneNumberCount ?
        else if( retStr.length() < mMiniCharacterCount )
            retStr = "";

        return retStr;
    }
}