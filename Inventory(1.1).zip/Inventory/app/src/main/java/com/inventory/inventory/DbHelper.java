////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  DbHelper.java
//  Inventory App For SQlite, Content Provider, Loader,  CursorAdapter
//
//  Created by Xiaoming Yu  on 02/02/2018.
//
////////////////////////////////////////////////////////////////////////////////////////////////////

// package class name
package com.inventory.inventory;
// import class name
import android.content.ContentValues;
import android.database.Cursor;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
// DbHelper class
public class DbHelper extends SQLiteOpenHelper {
    // variable
    // DB name
    private static final String DATABASE_NAME = "Inventor3.db";
    // Database version. If you change the database schema, you must increment the database version.
    private static final int DATABASE_VERSION = 1;
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // constructor
    //
    // inp: context - context
    //      version - version
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    public DbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // DB creator
    //
    // inp: db - DB for crate
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_CONTACTS_TABLE = "CREATE TABLE "
                + Contract.Entry.TABLE_NAME + "("
                + Contract.Entry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + Contract.Entry.COLUMN_BOOK_TITLE + " TEXT,"
                + Contract.Entry.COLUMN_BOOK_AUTHOR + " TEXT,"
                + Contract.Entry.COLUMN_BOOK_PRICE + " INTEGER,"
                + Contract.Entry.COLUMN_BOOK_QUANTITY + " INTEGER,"
                + Contract.Entry.COLUMN_BOOK_SUPPLIERNAME + " TEXT,"
                + Contract.Entry.COLUMN_BOOK_SUPPLIEREMAIL + " TEXT,"
                + Contract.Entry.COLUMN_BOOK_SUPPLIERPHONE + " TEXT,"
                + Contract.Entry.COLUMN_BOOK_IMAGE + " TEXT" + ")";
        db.execSQL(CREATE_CONTACTS_TABLE);
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // DB upgrade
    //
    // inp: db - DB for create
    //      oldVersion - old version
    //      newVersion - new version
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }
}