////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  SeeActivity.java
//  Inventory App For SQlite, Content Provider, Loader,  CursorAdapter
//
//  Created by Xiaoming Yu  on 02/02/2018.
//
////////////////////////////////////////////////////////////////////////////////////////////////////

// package class name
package com.inventory.inventory;
// import class name
import android.app.AlertDialog;
import android.app.LoaderManager;
import android.content.ContentValues;
import android.content.CursorLoader;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.Loader;
import android.database.Cursor;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;
// SeeActivity class
public class SeeActivity extends AppCompatActivity
        implements LoaderManager.LoaderCallbacks<Cursor>{
    /// Content URI
    private Uri mCurrentBookUri;
    // column controls
    private TextView mTitleTextView;
    private TextView mAuthorTextView;
    private TextView mPriceTextView;
    private TextView mQuantityTextView;
    private TextView mSupliernameTextView;
    private TextView mSuplieremailTextView;
    private TextView mSuplierphoneTextView;
    private ImageView mImageView;
    //  radio for image select
    private RadioGroup mBookKindGroup;
    private RadioButton radioSexButton;
    private RadioButton mBook1Radio;
    private RadioButton mBook2Radio;
    private RadioButton mBook3Radio;
    private RadioButton mBook4Radio;
    private RadioButton mBook5Radio;
    private int         mBookKind;
    // column value
    String  mTitle;
    String  mAuthorStr;
    int     mPrice;
    int     mQuantity;
    String  mSupliername;
    String  mSuplieremail;
    String  mSuplierphone;
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // create
    //
    // inp: savedInstanceState - bundle
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_see);
        // Examine the intent that was used to launch this activity,
        // in order to figure out if we're creating a new book or editing an existing one.
        Intent intent = getIntent();
        mCurrentBookUri = intent.getData();
        // Initialize a loader to read the book data from the database
        // and display the current values in the editor
        getLoaderManager().initLoader(Contract.BOOK_LOADER, null, this);
        // get the control
        mTitleTextView          = (TextView)findViewById(R.id.titleContent);
        mAuthorTextView         = (TextView)findViewById(R.id.authorContent);
        mPriceTextView          = (TextView)findViewById(R.id.priceContent);
        mQuantityTextView       = (TextView)findViewById(R.id.quantityContent);
        mSupliernameTextView    = (TextView)findViewById(R.id.suplierNameContent);
        mSuplieremailTextView   = (TextView)findViewById(R.id.suplierEmailContent);
        mSuplierphoneTextView   = (TextView)findViewById(R.id.suplierPhoneContent);
        mImageView              = (ImageView)findViewById(R.id.image);
        // image
        mBook1Radio = (RadioButton) findViewById(R.id.book1);
        mBook2Radio = (RadioButton) findViewById(R.id.book2);
        mBook3Radio = (RadioButton) findViewById(R.id.book3);
        mBook4Radio = (RadioButton) findViewById(R.id.book4);
        mBook5Radio = (RadioButton) findViewById(R.id.book5);
        // title set
        getSupportActionBar().setTitle( R.string.title_seeDetails );
        // add the back button
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        // 'Delete' button process
        Button deleteBtn = (Button) findViewById(R.id.deleteBtn);
        // Capture button clicks
        deleteBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                builder.setMessage(R.string.one_delete_dialog_msg);
                builder.setPositiveButton(R.string.ok_dialog_btn, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // Call the ContentResolver to delete the pet at the given content URI.
                        // Pass in null for the selection and selection args because the mCurrentPetUri
                        // content URI already identifies the pet that we want.
                        int rowsDeleted = getContentResolver().delete(mCurrentBookUri, null, null);
                        onMovetoMainActivity();
                    }
                });
                builder.setNegativeButton(R.string.cancel_dialog_btn, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // User clicked the "Cancel" button, so dismiss the dialog
                        // and continue editing the pet.
                        if (dialog != null) {
                            dialog.dismiss();
                        }
                    }
                });
                // Create and show the AlertDialog
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }
         });
        // 'Order' button process
        Button orderBtn = (Button) findViewById(R.id.orderBtn);
        // Capture button clicks
        orderBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
            // send the email
            String toEmail = mSuplieremail;
            String message =
                    "Title : " + mTitle +
                    "\nAuthor : " + mAuthorStr +
                    "\nPrice : " + Integer.toString(mPrice) +
                    "\nQunatity : " + Integer.toString(mQuantity) +
                    "\nSuplier Name : " + mSupliername +
                    "\nSuplier Email : " + mSuplieremail +
                    "\nSuplier Phone number : " + mSuplierphone +
                    "\nBook Kind : " + Integer.toString( mBookKind );

            Intent emailIntent = new Intent(Intent.ACTION_SEND);
            emailIntent.setType("message/rfc822");
            emailIntent.putExtra(Intent.EXTRA_EMAIL  , new String[]{mSuplieremail});
            emailIntent.putExtra(Intent.EXTRA_SUBJECT, R.string.app_name);
            emailIntent.putExtra(Intent.EXTRA_TEXT, message);
            startActivity(Intent.createChooser(emailIntent, getResources().getString(R.string.email_sending_msg)));
            }
        });
        // '-' button process
        Button decreaseBtn = (Button) findViewById(R.id.decreaseBtn);
        // Capture button clicks
        decreaseBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
            if ( mQuantity <= 0 )
            {
                Toast.makeText(getApplicationContext(),
                    R.string.quantityZero, Toast.LENGTH_SHORT).show();
            }
            else
            {
                mQuantity -= 1;
                onQuantityModify();
                mQuantityTextView.setText(Integer.toString(mQuantity));
            }
            }
        });
        // '+' button process
        Button increaseBtn = (Button) findViewById(R.id.increaseBtn);
        // Capture button clicks
        increaseBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                mQuantity += 1;
                onQuantityModify();
                onQuantityModify();
                mQuantityTextView.setText(Integer.toString(mQuantity));
            }
        });
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // quantity modify
    //
    // inp: none
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    private void onQuantityModify() {
        // get the data
        ContentValues values = new ContentValues();
        values.put(Contract.Entry.COLUMN_BOOK_TITLE, mTitle);
        values.put(Contract.Entry.COLUMN_BOOK_AUTHOR, mAuthorStr);
        values.put(Contract.Entry.COLUMN_BOOK_PRICE, mPrice);
        values.put(Contract.Entry.COLUMN_BOOK_QUANTITY, mQuantity);
        values.put(Contract.Entry.COLUMN_BOOK_SUPPLIERNAME, mSupliername);
        values.put(Contract.Entry.COLUMN_BOOK_SUPPLIEREMAIL, mSuplieremail);
        values.put(Contract.Entry.COLUMN_BOOK_SUPPLIERPHONE, mSuplierphone);
        values.put(Contract.Entry.COLUMN_BOOK_IMAGE, mBookKind);
        // upde  the data
        int rowsAffected = getContentResolver().update(mCurrentBookUri, values, null, null);
        // Show a toast message depending on whether or not the update was successful.
        if (rowsAffected == 0) {
            Toast.makeText(this,
                    R.string.db_update_error, Toast.LENGTH_SHORT).show();
        }
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // menu ceate
    //
    // inp: menu - ceate menu
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // add menu
        getMenuInflater().inflate(R.menu.menu_edit, menu);
        return true;
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // go to all inventory
    //
    // inp: none
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    void onMovetoMainActivity()
    {
        Intent intent = new Intent(SeeActivity.this, MainActivity.class);
        startActivity(intent);
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // menu provcess
    //
    // inp: item - menu iterm
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                // app icon in action bar clicked; goto parent activity.
                onMovetoMainActivity();
                return true;
            case R.id.edit:
                // go to edit activity
                Intent intent = new Intent(SeeActivity.this, EditActivity.class);
                // Set the URI on the data field of the intent
                intent.setData(mCurrentBookUri);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // Create loader
    //
    // inp: idx - index
    //      bundle - bundle
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public Loader<Cursor> onCreateLoader(int idx, Bundle bundle) {
        // Since the editor shows all book attributes, define a projection that contains
        // all columns from the book table
        String[] projection = {
                Contract.Entry._ID,
                Contract.Entry.COLUMN_BOOK_TITLE,
                Contract.Entry.COLUMN_BOOK_AUTHOR,
                Contract.Entry.COLUMN_BOOK_PRICE,
                Contract.Entry.COLUMN_BOOK_QUANTITY,
                Contract.Entry.COLUMN_BOOK_SUPPLIERNAME,
                Contract.Entry.COLUMN_BOOK_SUPPLIEREMAIL,
                Contract.Entry.COLUMN_BOOK_SUPPLIERPHONE,
                Contract.Entry.COLUMN_BOOK_IMAGE };

        // This loader will execute the ContentProvider's query method on a background thread
        return new CursorLoader(this,   // Parent activity context
                mCurrentBookUri,                // Query the content URI for the current book
                projection,                     // Columns to include in the resulting Cursor
                null,                  // No selection clause
                null,               // No selection arguments
                null);                 // Default sort order
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // loader  finished
    //
    // inp: loader - loader
    //      cursor - cursor
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
        // Bail early if the cursor is null or there is less than 1 row in the cursor
        if (cursor == null || cursor.getCount() < 1) {
            return;
        }
        // Proceed with moving to the first row of the cursor and reading data from it
        // (This should be the only row in the cursor)
        if (cursor.moveToFirst()) {
            // get the columns of book attributes that we're interested in
            int titleColumnIndex = cursor.getColumnIndex(Contract.Entry.COLUMN_BOOK_TITLE);
            int authorColumnIndex = cursor.getColumnIndex(Contract.Entry.COLUMN_BOOK_AUTHOR);
            int priceColumnIndex = cursor.getColumnIndex(Contract.Entry.COLUMN_BOOK_PRICE);
            int quantityColumnIndex = cursor.getColumnIndex(Contract.Entry.COLUMN_BOOK_QUANTITY);
            int supliernameColumnIndex = cursor.getColumnIndex(Contract.Entry.COLUMN_BOOK_SUPPLIERNAME);
            int suplieremailColumnIndex = cursor.getColumnIndex(Contract.Entry.COLUMN_BOOK_SUPPLIEREMAIL);
            int suplierphoneColumnIndex = cursor.getColumnIndex(Contract.Entry.COLUMN_BOOK_SUPPLIERPHONE);
            // load the column
            // title
            mTitle = cursor.getString( titleColumnIndex );
            mTitleTextView.setText(mTitle);
            // author
            mAuthorStr = cursor.getString( authorColumnIndex );
            mAuthorTextView.setText(mAuthorStr);
            // price
            mPrice = cursor.getInt( priceColumnIndex );
            mPriceTextView.setText( Integer.toString(mPrice) );
            // quantity
            mQuantity = cursor.getInt( quantityColumnIndex );
            mQuantityTextView.setText( Integer.toString(mQuantity) );
            // Supliername
            mSupliername = cursor.getString( supliernameColumnIndex );
            mSupliernameTextView.setText(mSupliername);
            // Suplieremail
            mSuplieremail = cursor.getString( suplieremailColumnIndex );
            mSuplieremailTextView.setText(mSuplieremail);
            // Suplierphone
            mSuplierphone = cursor.getString( suplierphoneColumnIndex );
            mSuplierphoneTextView.setText(mSuplierphone);
            // image
            int imageColumnIndex = cursor.getColumnIndex(Contract.Entry.COLUMN_BOOK_IMAGE);
            mBookKind = cursor.getInt( imageColumnIndex );
            switch(mBookKind)
            {
                case 0:
                    mBook1Radio.setChecked(true);
                    mImageView.setImageResource( R.drawable.book1 );
                    break;
                case 1:
                    mBook2Radio.setChecked(true);
                    mImageView.setImageResource( R.drawable.book2 );
                    break;
                case 2:
                    mBook3Radio.setChecked(true);
                    mImageView.setImageResource( R.drawable.book3 );
                    break;
                case 3:
                    mBook4Radio.setChecked(true);
                    mImageView.setImageResource( R.drawable.book4 );
                    break;
                default:
                    mBook5Radio.setChecked(true);
                    mImageView.setImageResource( R.drawable.book5 );
                    break;
            }
        }
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // loader  reset
    //
    // inp: loader - loader
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        // If the loader is invalidated, clear out all the data from the input fields.
        mTitleTextView.setText( "" );
        mAuthorTextView.setText( "" );
        mPriceTextView.setText( "0" );
        mQuantityTextView.setText( "0" );
        mSupliernameTextView.setText( "" );
        mSuplieremailTextView.setText( "" );
        mSuplierphoneTextView.setText( "" );
        // image
        mBookKind = 0;
        mImageView.setImageResource( R.drawable.book1 );
        mBook1Radio.setChecked(true);
        mBook2Radio.setChecked(false);
        mBook3Radio.setChecked(false);
        mBook4Radio.setChecked(false);
        mBook5Radio.setChecked(false);

    }
}