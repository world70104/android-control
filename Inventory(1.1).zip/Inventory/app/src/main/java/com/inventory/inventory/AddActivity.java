////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  AddActivity.java
//  Inventory App For SQlite, Content Provider, Loader,  CursorAdapter
//
//  Created by Xiaoming Yu  on 02/02/2018.
//
////////////////////////////////////////////////////////////////////////////////////////////////////

// package class name
package com.inventory.inventory;
// import class name
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
// AddActivity class
public class AddActivity extends AppCompatActivity {
    // column controls
    private TextView    mTitleTextView;
    private TextView    mAuthorTextView;
    private TextView    mPriceTextView;
    private TextView    mQuantityTextView;
    private TextView    mSupliernameTextView;
    private TextView    mSuplieremailTextView;
    private TextView    mSuplierphoneTextView;
    private ImageView   mImageView;
    //  radio for image select
    private RadioGroup  mBookKindGroup;
    private RadioButton mBook1Radio;
    private RadioButton mBook2Radio;
    private RadioButton mBook3Radio;
    private RadioButton mBook4Radio;
    private RadioButton mBook5Radio;
    private int         mBookKind;
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // create
    //
    // inp: savedInstanceState - bundle
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        // get control
        mTitleTextView          = (TextView) findViewById(R.id.editTitle);
        mAuthorTextView         = (TextView) findViewById(R.id.editAuthor);
        mPriceTextView          = (TextView) findViewById(R.id.editPrice);
        mQuantityTextView       = (TextView) findViewById(R.id.editQuantity);
        mSupliernameTextView    = (TextView) findViewById(R.id.editSuplierName);
        mSuplieremailTextView   = (TextView) findViewById(R.id.editSuplierEmail);
        mSuplierphoneTextView   = (TextView) findViewById(R.id.editSuplierPhone);
        mImageView              = (ImageView) findViewById(R.id.image);
        // image radio
        mBookKind = 0;
        mBookKindGroup = (RadioGroup) findViewById(R.id.bookkind);
        mBook1Radio = (RadioButton) findViewById(R.id.book1);
        mBook2Radio = (RadioButton) findViewById(R.id.book2);
        mBook3Radio = (RadioButton) findViewById(R.id.book3);
        mBook4Radio = (RadioButton) findViewById(R.id.book4);
        mBook5Radio = (RadioButton) findViewById(R.id.book5);
        // default set by 0
        mBook1Radio.setChecked(true);
        // when select the book kind(radio)
        mBookKindGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
            if ( mBook1Radio.isChecked() ) {
                mImageView.setImageResource(R.drawable.book1);
                mBookKind = 0;
            }
            else if ( mBook2Radio.isChecked() ) {
                mImageView.setImageResource(R.drawable.book2);
                mBookKind = 1;
            }
            else if ( mBook3Radio.isChecked() ) {
                mImageView.setImageResource(R.drawable.book3);
                mBookKind = 2;
            }
            else if ( mBook4Radio.isChecked() ) {
                mImageView.setImageResource(R.drawable.book4);
                mBookKind = 3;
            }
            else {
                mImageView.setImageResource(R.drawable.book5);
                mBookKind = 4;
            }
            }
        });
        // 'add' title set
        getSupportActionBar().setTitle( R.string.title_add );
        // add the back button
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        // add 'add' button
        Button addBtn = (Button) findViewById(R.id.addBtn);
        // add button clicks
        addBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                onAddButton();
            }
        });
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // add the data
    //
    //  add new book data
    //
    // inp: none
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    public void onAddButton() {
         // validate check?
         ValidateCheck validateCheck = new ValidateCheck();
         // title validate check?
         String strTitle = validateCheck.CharacterValidateCheck(
                 mTitleTextView.getText().toString());
         if ( strTitle.isEmpty() )
         {
             Toast.makeText(this, getString(R.string.edit_titleError),
                     Toast.LENGTH_SHORT).show();
             return;
         }
         // author validate check?
         String strAuthor = validateCheck.CharacterValidateCheck(
                 mAuthorTextView.getText().toString());
         if ( strAuthor.isEmpty() )
         {
             Toast.makeText(this, getString(R.string.edit_authorError),
                     Toast.LENGTH_SHORT).show();
             return;
         }
         // price validate check?
         int intPrice = validateCheck.PriceQuantityValidateCheck(
                 mPriceTextView.getText().toString());
         if ( intPrice == -1 )
         {
             Toast.makeText(this, getString(R.string.edit_priceError),
                     Toast.LENGTH_SHORT).show();
             return;
         }
         // Quantity validate check?
         int intQuantity = validateCheck.PriceQuantityValidateCheck(
                 mQuantityTextView.getText().toString());
         if ( intQuantity == -1 )
         {
             Toast.makeText(this, getString(R.string.edit_quantityError),
                     Toast.LENGTH_SHORT).show();
             return;
         }
         // Suplier name validate check?
         String strSupliername = validateCheck.CharacterValidateCheck(
                 mSupliernameTextView.getText().toString());
         if ( strSupliername == "" )
         {
             Toast.makeText(this, getString(R.string.edit_supliernameError),
                     Toast.LENGTH_SHORT).show();
             return;
         }
         // Suplier name validate check?
         String strSuplieremail = validateCheck.EmailValidateCheck(
                 mSuplieremailTextView.getText().toString());
         if ( strSuplieremail == "" )
         {
             Toast.makeText(this, getString(R.string.edit_suplieremailError),
                     Toast.LENGTH_SHORT).show();
             return;
         }
         // Suplier name validate check?
         String strSuplierphone = validateCheck.PhoneNumberValidateCheck(
                 mSuplierphoneTextView.getText().toString());
         if ( strSuplierphone == "" )
         {
             Toast.makeText(this, getString(R.string.edit_suplierphoneError),
                     Toast.LENGTH_SHORT).show();
             return;
         }
         // get the new data
          ContentValues values = new ContentValues();
          values.put(Contract.Entry.COLUMN_BOOK_TITLE,         strTitle);
          values.put(Contract.Entry.COLUMN_BOOK_AUTHOR,        strAuthor);
          values.put(Contract.Entry.COLUMN_BOOK_PRICE,         intPrice);
          values.put(Contract.Entry.COLUMN_BOOK_QUANTITY,      intQuantity);
          values.put(Contract.Entry.COLUMN_BOOK_SUPPLIERNAME,  strSupliername);
          values.put(Contract.Entry.COLUMN_BOOK_SUPPLIEREMAIL, strSuplieremail);
          values.put(Contract.Entry.COLUMN_BOOK_SUPPLIERPHONE, strSuplierphone);
          values.put(Contract.Entry.COLUMN_BOOK_IMAGE,         mBookKind );
          // Insert  into the provider using the ContentResolver.
          Uri newUri = getContentResolver().insert(Contract.Entry.CONTENT_URI, values);
          // go to all inventory
          onMoveMainActicvety();
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // go to all iventory
    //
    // inp: none
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    void onMoveMainActicvety()
    {
        Intent intent = new Intent(AddActivity.this, MainActivity.class);
        startActivity(intent);
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // menu process
    //
    // inp: item - menu iterm
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            // backup ?
            case android.R.id.home:
                // show ask dialog.
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setMessage(R.string.add_stop_dialog_msg);
                builder.setPositiveButton(R.string.ok_dialog_btn, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // If ok, go to all inventory
                        onMoveMainActicvety();
                    }
                });
                builder.setNegativeButton(R.string.cancel_dialog_btn, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // If cancel , cancel
                        if (dialog != null) {
                            dialog.dismiss();
                        }
                    }
                });
                // Create and show the AlertDialog
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}