////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  MainActivity.java
//  Inventory App For SQlite, Content Provider, Loader,  CursorAdapter
//
//  Created by Xiaoming Yu  on 02/02/2018.
//
////////////////////////////////////////////////////////////////////////////////////////////////////

// package class name
package com.inventory.inventory;
// import class name
import android.app.AlertDialog;
import android.app.LoaderManager;
import android.content.ContentUris;
import android.content.CursorLoader;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.Loader;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

// MainActivity class
public class MainActivity extends AppCompatActivity
    implements LoaderManager.LoaderCallbacks<Cursor> {
    // Adapter for the ListView
    BookCursorAdapter mCursorAdapter;
    // list view for book
    ListView mBookListView;
    TextView mInstructionTextView;
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // create
    //
    // inp: savedInstanceState - bundle
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Find the ListView which will be populated with the book data
        mBookListView = (ListView) findViewById(R.id.list);
        // get the instruction textview
        mInstructionTextView = (TextView) findViewById(R.id.instruction);
        // Setup an Adapter to create a list item for each row of book data in the Cursor.
        mCursorAdapter = new BookCursorAdapter(this, null);
        mBookListView.setAdapter(mCursorAdapter);
        // Setup the item click listener
        mBookListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
            // Create new intent
            Intent intent = new Intent(MainActivity.this, SeeActivity.class);
            // Uri set
            Uri currentBookUri = ContentUris.withAppendedId(Contract.Entry.CONTENT_URI, id);
            // Set the URI on the data field of the intent
            intent.setData(currentBookUri);
            // go to see activity
            startActivity(intent);
            }
        });
        // Kick off the loader
        getLoaderManager().initLoader( Contract.BOOK_LOADER, null, this);
        // set the title
        getSupportActionBar().setTitle( R.string.title_allInvenyory );
        // set the instruction text view
        onSetInstructionTextView();
        mBookListView.setVisibility(View.VISIBLE);
        mInstructionTextView.setVisibility(View.GONE);
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // menu ceate
    //
    // inp: menu - ceate menu
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_all, menu);
        return true;
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // menu provcess
    //
    // inp: item - menu iterm
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_add:
                // go to add activity
                Intent intent = new Intent(MainActivity.this, AddActivity.class);
                startActivity(intent);
                return true;
            case R.id.menu_all_delete:
                deleteAllBooks();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // delete all data
    //
    // inp: none
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    private void deleteAllBooks() {
        // show ask dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.all_delete_dialog_msg);
        builder.setPositiveButton(R.string.ok_dialog_btn, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            // all delete
            int rowsDeleted = getContentResolver().delete(Contract.Entry.CONTENT_URI, null, null);
            }
        });
        builder.setNegativeButton(R.string.cancel_dialog_btn, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                if (dialog != null) {
                    dialog.dismiss();
                }
            }
        });
        // Create and show the AlertDialog
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // Create loader
    //
    // inp: idx - index
    //      bundle - bundle
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public Loader<Cursor> onCreateLoader(int idx, Bundle bundle) {
        // Since the editor shows all book attributes, define a projection that contains
        // all columns from the book table
        String[] projection = {
            Contract.Entry._ID,
            Contract.Entry.COLUMN_BOOK_TITLE,
            Contract.Entry.COLUMN_BOOK_AUTHOR,
            Contract.Entry.COLUMN_BOOK_PRICE,
            Contract.Entry.COLUMN_BOOK_QUANTITY,
            Contract.Entry.COLUMN_BOOK_SUPPLIERNAME,
            Contract.Entry.COLUMN_BOOK_SUPPLIEREMAIL,
            Contract.Entry.COLUMN_BOOK_SUPPLIERPHONE,
            Contract.Entry.COLUMN_BOOK_IMAGE };
        // This loader will execute the ContentProvider's query method on a background thread
        return new CursorLoader(this,   // Parent activity context
            Contract.Entry.CONTENT_URI,     // Provider content URI to query
            projection,                     // Columns to include in the resulting Cursor
           null,                   // No selection clause
           null,                // No selection arguments
           null);                  // Default sort order
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // loader  finished
    //
    // inp: loader - loader
    //      cursor - cursor
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        // get the row count
        int rowCOunt = data.getCount();
        onShowControl(rowCOunt);
        // Update {@link BookCursorAdapter} with this new cursor containing updated book data
        mCursorAdapter.swapCursor(data);
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // loader  reset
    //
    // inp: loader - loader
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        // Callback called when the data needs to be deleted
        mCursorAdapter.swapCursor(null);
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // Set instruction textview
    //
    // inp: none
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    public void onSetInstructionTextView() {
        String instruction =
            getResources().getString( R.string.instruction_row_1 )
            + getResources().getString( R.string.instruction_row_2 )
            + getResources().getString( R.string.instruction_row_3 )
            + getResources().getString( R.string.instruction_row_4 )
            + getResources().getString( R.string.instruction_row_5 )
            + getResources().getString( R.string.instruction_row_6 )
            + getResources().getString( R.string.instruction_row_7 )
            + getResources().getString( R.string.instruction_row_8 )
            + getResources().getString( R.string.instruction_row_9 )
            + getResources().getString( R.string.instruction_row_10 )
            + getResources().getString( R.string.instruction_row_11 )
            + getResources().getString( R.string.instruction_row_12 )
            + getResources().getString( R.string.instruction_row_13 )
            + getResources().getString( R.string.instruction_row_14 )
            + getResources().getString( R.string.instruction_row_15 )
            + getResources().getString( R.string.instruction_row_16 )
            + getResources().getString( R.string.instruction_row_17 )
            + getResources().getString( R.string.instruction_row_18 )
            + getResources().getString( R.string.instruction_row_19 );
        mInstructionTextView.setText( instruction );
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // show control
    //
    // if the column count is 0, show instruction view
    // other show book list view
    //
    // inp: zeroDBCount - column count
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    void onShowControl( int zeroDBCount ) {
        // If database's iterm count is 0, instruction view show
        // other book list view show
        if ( zeroDBCount == 0 )
        {
            mBookListView.setVisibility(View.GONE);
            mInstructionTextView.setVisibility(View.VISIBLE);
        }
        else
        {
            mBookListView.setVisibility(View.VISIBLE);
            mInstructionTextView.setVisibility(View.GONE);
        }
    }
}