////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  BookCursorAdapter.java
//  Inventory App For SQlite, Content Provider, Loader,  CursorAdapter
//
//  Created by Xiaoming Yu  on 02/02/2018.
//
////////////////////////////////////////////////////////////////////////////////////////////////////

// package class name
package com.inventory.inventory;
// import class name
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CursorAdapter;
import android.widget.TextView;
import android.widget.Toast;
import com.inventory.inventory.Contract;
import java.util.ArrayList;
import java.util.List;
// BookCursorAdapter class
public class BookCursorAdapter extends CursorAdapter {
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // constructor
    //
    // inp: context - context
    //      cursor - cursor
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    public BookCursorAdapter(Context context, Cursor cursor) {
        super(context, cursor, 0 /* flags */);
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // Makes a new blank list item view. No data is set (or bound) to the views yet.
    //
    // inp: context - context
    //      cursor - The cursor from which to get the data. The cursor is already
    //                moved to the correct position.
    //      parent -  The parent to which the new view is attached to
    // out: the newly created list item view
    ////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        // Inflate a list item view using the layout specified in list_item.xml
        return LayoutInflater.from(context).inflate(R.layout.list_item, parent, false);
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // This method binds the pet data (in the current row pointed to by cursor) to the given
    // list item layout. For example, the name for the current pet can be set on the name TextView
    // in the list item layout.
    //
    // inp: view - Existing view, returned earlier by newView() method
    //      context - context
    //      cursor - The cursor from which to get the data. The cursor is already moved to the
    //                correct row.
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public void bindView(View view, Context context, Cursor cursor) {
        // get the controls  in the list item layout
        TextView titleTextView      = (TextView) view.findViewById(R.id.listitem_title);
        TextView priceTextView      = (TextView) view.findViewById(R.id.listitem_price);
        TextView quantityTextView   = (TextView) view.findViewById(R.id.listitem_quantity);
        // get the columns index
        int titleColumnIndex        = cursor.getColumnIndex(Contract.Entry.COLUMN_BOOK_TITLE);
        int authorColumnIndex       = cursor.getColumnIndex(Contract.Entry.COLUMN_BOOK_AUTHOR);
        int priceColumnIndex        = cursor.getColumnIndex(Contract.Entry.COLUMN_BOOK_PRICE);
        int quantityColumnIndex     = cursor.getColumnIndex(Contract.Entry.COLUMN_BOOK_QUANTITY);
        int supliernameColumnIndex  = cursor.getColumnIndex(Contract.Entry.COLUMN_BOOK_SUPPLIERNAME);
        int suplieremailColumnIndex = cursor.getColumnIndex(Contract.Entry.COLUMN_BOOK_SUPPLIEREMAIL);
        int suplierphoneColumnIndex = cursor.getColumnIndex(Contract.Entry.COLUMN_BOOK_SUPPLIERPHONE);
        int imageColumnIndex        = cursor.getColumnIndex(Contract.Entry.COLUMN_BOOK_IMAGE);
        // get the columns
        String title        = cursor.getString( titleColumnIndex );
        String author       = cursor.getString( authorColumnIndex );
        int    price        = cursor.getInt( priceColumnIndex );
        int    quantity     = cursor.getInt( quantityColumnIndex );
        String supliername  = cursor.getString( supliernameColumnIndex );
        String suplieremail = cursor.getString( suplieremailColumnIndex );
        String suplierphone = cursor.getString( suplierphoneColumnIndex );
        int    bookKind     = cursor.getInt( imageColumnIndex );
        // set the list iterm
        titleTextView.setText(title);
        priceTextView.setText(Integer.toString(price));
        quantityTextView.setText(Integer.toString(quantity));
        // 'sale' process
        Button saleBtn = (Button) view.findViewById(R.id.saleButton);
        // get the position
        int position = cursor.getPosition();
        // ready the pass data
        List<String> data = new ArrayList<String>();
        data.add(Integer.toString(position));
        data.add(title);
        data.add(author);
        data.add(Integer.toString(price));
        data.add(Integer.toString(quantity));
        data.add(supliername);
        data.add(suplieremail);
        data.add(suplierphone);
        data.add(Integer.toString(bookKind));
        saleBtn.setTag(data);
        // when press 'sale' button
        saleBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // get the passed data
                // get position
                int position = Integer.parseInt( ((List<String>)v.getTag()).get(0));
                // get ID
                long id = getItemId( position );
                // get the column
                String title        = ((List<String>)v.getTag()).get(1);
                String author       = ((List<String>)v.getTag()).get(2);
                int    price        = Integer.parseInt( ((List<String>)v.getTag()).get(3));
                int    quantity     = Integer.parseInt( ((List<String>)v.getTag()).get(4));
                String supliername  = ((List<String>)v.getTag()).get(5);
                String suplieremail = ((List<String>)v.getTag()).get(6);
                String suplierphone = ((List<String>)v.getTag()).get(7);
                int    bookKind     = Integer.parseInt( ((List<String>)v.getTag()).get(8));
                // check quantity zero?
                if ( quantity <= 0 ) {
                    Toast.makeText(v.getContext(),
                            R.string.quantityZero, Toast.LENGTH_SHORT).show();
                }
                else {
                    // quantity >= zero?
                    quantity -= 1;
                    // Update the data
                    ContentValues values = new ContentValues();
                    values.put(Contract.Entry.COLUMN_BOOK_TITLE, title);
                    values.put(Contract.Entry.COLUMN_BOOK_AUTHOR, author);
                    values.put(Contract.Entry.COLUMN_BOOK_PRICE, price);
                    values.put(Contract.Entry.COLUMN_BOOK_QUANTITY, quantity);
                    values.put(Contract.Entry.COLUMN_BOOK_SUPPLIERNAME, supliername);
                    values.put(Contract.Entry.COLUMN_BOOK_SUPPLIEREMAIL, suplieremail);
                    values.put(Contract.Entry.COLUMN_BOOK_SUPPLIERPHONE, suplierphone);
                    values.put(Contract.Entry.COLUMN_BOOK_IMAGE, bookKind);
                    // set the uri
                    Uri currentBookUri = ContentUris.withAppendedId(Contract.Entry.CONTENT_URI, id);
                    // Update
                    int rowsAffected = v.getContext().getContentResolver().update(currentBookUri, values, null, null);
                    // Show a toast message depending on whether or not the update was successful.
                    if (rowsAffected == 0) {
                        Toast.makeText(v.getContext(),
                                R.string.db_update_error, Toast.LENGTH_SHORT).show();
                    }
                    notifyDataSetChanged();
                }
            }
        });
    }
}
