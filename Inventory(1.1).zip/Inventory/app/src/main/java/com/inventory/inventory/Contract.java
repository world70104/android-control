////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  Contract.java
//  Inventory App For SQlite, Content Provider, Loader,  CursorAdapter
//
//  Created by Xiaoming Yu  on 02/02/2018.
//
////////////////////////////////////////////////////////////////////////////////////////////////////

// package class name
package com.inventory.inventory;
// import class name
import android.content.ContentResolver;
import android.net.Uri;
import android.provider.BaseColumns;
// Contract class
public class Contract {
    // The "Content authority" is a name for the entire content provider
    public static final String CONTENT_AUTHORITY = "com.inventory.books";
    // URI's which apps will use to contact the content provider
    public static final Uri BASE_CONTENT_URI = Uri.parse("content://"+CONTENT_AUTHORITY);
    // Possible path (appended to base content URI for possible URI's)
    public static final String PATH_BOOKS = "books";
    // Identifier for the loader */
    public static final int BOOK_LOADER = 0;
    // Inner class that defines constant values for the pets database table.
    public static class Entry implements BaseColumns {
    // The content URI to access the pet data in the provider */
    public static final Uri CONTENT_URI = Uri.withAppendedPath(BASE_CONTENT_URI, PATH_BOOKS);
    // The MIME type of the {@link #CONTENT_URI} for a list of pets.
    public static final String CONTENT_LIST_TYPE =
        ContentResolver.CURSOR_DIR_BASE_TYPE + "/" + CONTENT_AUTHORITY + "/" + PATH_BOOKS;
    public static final String CONTENT_ITEM_TYPE =
        ContentResolver.CURSOR_ITEM_BASE_TYPE + "/" + CONTENT_AUTHORITY + "/" + PATH_BOOKS;
    // database table name
    public final static String TABLE_NAME = "books";
    // Unique ID number for the book (only for use in the database table).
    public final static String _ID = BaseColumns._ID;
     // Columns names
    static final String COLUMN_BOOK_ID =            "id";
    static final String COLUMN_BOOK_TITLE =         "title";
    static final String COLUMN_BOOK_AUTHOR =        "author";
    static final String COLUMN_BOOK_PRICE =         "price";
    static final String COLUMN_BOOK_QUANTITY =      "quantity";
    static final String COLUMN_BOOK_SUPPLIERNAME =  "suppliername";
    static final String COLUMN_BOOK_SUPPLIEREMAIL = "supplieremail";
    static final String COLUMN_BOOK_SUPPLIERPHONE = "supplierphone";
    static final String COLUMN_BOOK_IMAGE =          "image";
    }
}