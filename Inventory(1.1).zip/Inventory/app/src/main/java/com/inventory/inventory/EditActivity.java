////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  EditActivity.java
//  Inventory App For SQlite, Content Provider, Loader,  CursorAdapter
//
//  Created by Xiaoming Yu  on 02/02/2018.
//
////////////////////////////////////////////////////////////////////////////////////////////////////

// package class name
package com.inventory.inventory;
// import class name
import android.app.AlertDialog;
import android.app.LoaderManager;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.CursorLoader;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.Loader;
import android.database.Cursor;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
//  EditActivity class
public class EditActivity extends AppCompatActivity
        implements LoaderManager.LoaderCallbacks<Cursor>{
    /// Content URI
    private Uri mCurrentBookUri;
    // column controls
    private TextView mTitleTextView;
    private TextView mAuthorTextView;
    private TextView mPriceTextView;
    private TextView mQuantityTextView;
    private TextView mSupliernameTextView;
    private TextView mSuplieremailTextView;
    private TextView mSuplierphoneTextView;
    private ImageView mImageView;
    //  radio for image select
    private RadioGroup mBookKindGroup;
    private RadioButton radioSexButton;
    private RadioButton mBook1Radio;
    private RadioButton mBook2Radio;
    private RadioButton mBook3Radio;
    private RadioButton mBook4Radio;
    private RadioButton mBook5Radio;
    private int         mBookKind;
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // create
    //
    // inp: savedInstanceState - bundle
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);
        // get the Uri
        Intent intent = getIntent();
        mCurrentBookUri = intent.getData();
        getLoaderManager().initLoader(Contract.BOOK_LOADER, null, this);
        // get control
        mTitleTextView          = (TextView) findViewById(R.id.editTitle);
        mAuthorTextView         = (TextView) findViewById(R.id.editAuthor);
        mPriceTextView          = (TextView) findViewById(R.id.editPrice);
        mQuantityTextView       = (TextView) findViewById(R.id.editQuantity);
        mSupliernameTextView    = (TextView) findViewById(R.id.editSuplierName);
        mSuplieremailTextView   = (TextView) findViewById(R.id.editSuplierEmail);
        mSuplierphoneTextView   = (TextView) findViewById(R.id.editSuplierPhone);
        mImageView              = (ImageView) findViewById(R.id.image);
        // image radio
        mBookKind = 0;
        mBookKindGroup  = (RadioGroup) findViewById(R.id.bookkind);
        mBook1Radio     = (RadioButton) findViewById(R.id.book1);
        mBook2Radio     = (RadioButton) findViewById(R.id.book2);
        mBook3Radio     = (RadioButton) findViewById(R.id.book3);
        mBook4Radio     = (RadioButton) findViewById(R.id.book4);
        mBook5Radio     = (RadioButton) findViewById(R.id.book5);
        mBook1Radio.setChecked(true);
        // when select the book kind(radio)
        mBookKindGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
            if ( mBook1Radio.isChecked() ) {
                mImageView.setImageResource(R.drawable.book1);
                mBookKind = 0;
            }
            else if ( mBook2Radio.isChecked() ) {
                mImageView.setImageResource(R.drawable.book2);
                mBookKind = 1;
            }
            else if ( mBook3Radio.isChecked() ) {
                mImageView.setImageResource(R.drawable.book3);
                mBookKind = 2;
            }
            else if ( mBook4Radio.isChecked() ) {
                mImageView.setImageResource(R.drawable.book4);
                mBookKind = 3;
            }
            else {
                mImageView.setImageResource(R.drawable.book5);
                mBookKind = 4;
            }
            }
        });
        // TITLE SET
        getSupportActionBar().setTitle( R.string.title_edit );
        // add the back button
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        // Add the update buttom
        Button button = (Button) findViewById(R.id.updateBtn);
        // Capture button clicks
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                onUpdate();
            }
        });
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // menu provcess
    //
    // inp: item - menu iterm
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                // show ask dialog.
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setMessage(R.string.edit_stop_dialog_msg);
                builder.setPositiveButton(R.string.ok_dialog_btn, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // go to see activity
                        Intent intent = new Intent(EditActivity.this, SeeActivity.class);
                        // Set the URI
                        intent.setData(mCurrentBookUri);
                        startActivity(intent);
                    }
                });
                builder.setNegativeButton(R.string.cancel_dialog_btn, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // User clicked the "Cancel" button, so dismiss the dialog
                        if (dialog != null) {
                            dialog.dismiss();
                        }
                    }
                });
                // Create and show the AlertDialog
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // Update provcess
    //
    // inp: none
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    private void onUpdate() {
        // validate check?
        ValidateCheck validateCheck = new ValidateCheck();
        // title validate check?
        String strTitle = validateCheck.CharacterValidateCheck( mTitleTextView.getText().toString() );
        if ( strTitle.isEmpty() )
        {
            Toast.makeText(this, getString(R.string.edit_titleError),
                    Toast.LENGTH_SHORT).show();
            return;
        }
        // author validate check?
        String strAuthor = validateCheck.CharacterValidateCheck( mAuthorTextView.getText().toString() );
        if ( strAuthor.isEmpty() )
        {
            Toast.makeText(this, getString(R.string.edit_authorError),
                    Toast.LENGTH_SHORT).show();
            return;
        }
        // price validate check?
        int intPrice = validateCheck.PriceQuantityValidateCheck( mPriceTextView.getText().toString() );
        if ( intPrice == -1 )
        {
            Toast.makeText(this, getString(R.string.edit_priceError),
                    Toast.LENGTH_SHORT).show();
            return;
        }
        // Quantity validate check?
        int intQuantity = validateCheck.PriceQuantityValidateCheck( mQuantityTextView.getText().toString() );
        if ( intQuantity == -1 )
        {
            Toast.makeText(this, getString(R.string.edit_quantityError),
                    Toast.LENGTH_SHORT).show();
            return;
        }
        // Suplier name validate check?
        String strSupliername = validateCheck.CharacterValidateCheck( mSupliernameTextView.getText().toString() );
        if ( strSupliername == "" )
        {
            Toast.makeText(this, getString(R.string.edit_supliernameError),
                    Toast.LENGTH_SHORT).show();
            return;
        }
        // Suplier name validate check?
        String strSuplieremail = validateCheck.EmailValidateCheck( mSuplieremailTextView.getText().toString() );
        if ( strSuplieremail == "" )
        {
            Toast.makeText(this, getString(R.string.edit_suplieremailError),
                    Toast.LENGTH_SHORT).show();
            return;
        }
        // Suplier name validate check?
        String strSuplierphone = validateCheck.PhoneNumberValidateCheck( mSuplierphoneTextView.getText().toString() );
        if ( strSuplierphone == "" )
        {
            Toast.makeText(this, getString(R.string.edit_suplierphoneError),
                    Toast.LENGTH_SHORT).show();
            return;
        }
        // get the new data
        ContentValues values = new ContentValues();
        values.put(Contract.Entry.COLUMN_BOOK_TITLE,         strTitle);
        values.put(Contract.Entry.COLUMN_BOOK_AUTHOR,        strAuthor);
        values.put(Contract.Entry.COLUMN_BOOK_PRICE,         intPrice);
        values.put(Contract.Entry.COLUMN_BOOK_QUANTITY,      intQuantity);
        values.put(Contract.Entry.COLUMN_BOOK_SUPPLIERNAME,  strSupliername);
        values.put(Contract.Entry.COLUMN_BOOK_SUPPLIEREMAIL, strSuplieremail);
        values.put(Contract.Entry.COLUMN_BOOK_SUPPLIERPHONE, strSuplierphone);
        values.put(Contract.Entry.COLUMN_BOOK_IMAGE,         mBookKind );
        // Update  into the provider using the ContentResolver.
        int rowsAffected = getContentResolver().update(mCurrentBookUri, values, null, null);
        // Show a toast message depending on whether or not the update was successful.
        if (rowsAffected == 0) {
            Toast.makeText(this,
                    R.string.db_update_error, Toast.LENGTH_SHORT).show();
        }
        // go to all inventory
        Intent intent = new Intent(EditActivity.this, MainActivity.class);
        // Set the URI on the data field of the intent
        intent.setData(mCurrentBookUri);
        startActivity(intent);
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // Create loader
    //
    // inp: idx - index
    //      bundle - bundle
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public Loader<Cursor> onCreateLoader(int idx, Bundle bundle) {
        // Since the editor shows all book attributes, define a projection that contains
        // all columns from the book table
        String[] projection = {
                Contract.Entry._ID,
                Contract.Entry.COLUMN_BOOK_TITLE,
                Contract.Entry.COLUMN_BOOK_AUTHOR,
                Contract.Entry.COLUMN_BOOK_PRICE,
                Contract.Entry.COLUMN_BOOK_QUANTITY,
                Contract.Entry.COLUMN_BOOK_SUPPLIERNAME,
                Contract.Entry.COLUMN_BOOK_SUPPLIEREMAIL,
                Contract.Entry.COLUMN_BOOK_SUPPLIERPHONE,
                Contract.Entry.COLUMN_BOOK_IMAGE };
        // This loader will execute the ContentProvider's query method on a background thread
        return new CursorLoader(this,   // Parent activity context
                mCurrentBookUri,                // Query the content URI for the current pet
                projection,                     // Columns to include in the resulting Cursor
                null,                  // No selection clause
                null,               // No selection arguments
                null);                 // Default sort order
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // loader  finished
    //
    // inp: loader - loader
    //      cursor - cursor
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
        // Bail early if the cursor is null or there is less than 1 row in the cursor
        if (cursor == null || cursor.getCount() < 1) {
            return;
        }
        // Proceed with moving to the first row of the cursor and reading data from it
        if (cursor.moveToFirst()) {
            // Find the columns of pet attributes that we're interested in
            int titleColumnIndex        = cursor.getColumnIndex(Contract.Entry.COLUMN_BOOK_TITLE);
            int authorColumnIndex       = cursor.getColumnIndex(Contract.Entry.COLUMN_BOOK_AUTHOR);
            int priceColumnIndex        = cursor.getColumnIndex(Contract.Entry.COLUMN_BOOK_PRICE);
            int quantityColumnIndex     = cursor.getColumnIndex(Contract.Entry.COLUMN_BOOK_QUANTITY);
            int supliernameColumnIndex  = cursor.getColumnIndex(Contract.Entry.COLUMN_BOOK_SUPPLIERNAME);
            int suplieremailColumnIndex = cursor.getColumnIndex(Contract.Entry.COLUMN_BOOK_SUPPLIEREMAIL);
            int suplierphoneColumnIndex = cursor.getColumnIndex(Contract.Entry.COLUMN_BOOK_SUPPLIERPHONE);
            // set the value
            mTitleTextView.setText( cursor.getString( titleColumnIndex ) );
            mAuthorTextView.setText( cursor.getString( authorColumnIndex ) );
            mPriceTextView.setText( Integer.toString( cursor.getInt( priceColumnIndex ) ) );
            mQuantityTextView.setText( Integer.toString( cursor.getInt( quantityColumnIndex ) ) );
            mSupliernameTextView.setText( cursor.getString( supliernameColumnIndex ) );
            mSuplieremailTextView.setText( cursor.getString( suplieremailColumnIndex ) );
            mSuplierphoneTextView.setText( cursor.getString( suplierphoneColumnIndex ) );
            // image process
            int imageColumnIndex = cursor.getColumnIndex(Contract.Entry.COLUMN_BOOK_IMAGE);
            int imgIndex = cursor.getInt( imageColumnIndex );
            switch(imgIndex)
            {
                case 0:
                    mBook1Radio.setChecked(true);
                    mImageView.setImageResource( R.drawable.book1 );
                    break;
                case 1:
                    mBook2Radio.setChecked(true);
                    mImageView.setImageResource( R.drawable.book2 );
                    break;
                case 2:
                    mBook3Radio.setChecked(true);
                    mImageView.setImageResource( R.drawable.book3 );
                    break;
                case 3:
                    mBook4Radio.setChecked(true);
                    mImageView.setImageResource( R.drawable.book4 );
                    break;
                default:
                    mBook5Radio.setChecked(true);
                    mImageView.setImageResource( R.drawable.book5 );
                    break;
            }
        }
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////
    // loader  reset
    //
    // inp: loader - loader
    // out: none
    ////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        // If the loader is invalidated, clear out all the data from the input fields.
        // control init
        mTitleTextView.setText( "" );
        mAuthorTextView.setText( "" );
        mPriceTextView.setText( "0" );
        mQuantityTextView.setText( "0" );
        mSupliernameTextView.setText( "" );
        mSuplieremailTextView.setText( "" );
        mSuplierphoneTextView.setText( "" );
        // image init
        mBookKind = 0;
        mImageView.setImageResource( R.drawable.book1 );
        mBook1Radio.setChecked(true);
        mBook2Radio.setChecked(false);
        mBook3Radio.setChecked(false);
        mBook4Radio.setChecked(false);
        mBook5Radio.setChecked(false);

    }
}